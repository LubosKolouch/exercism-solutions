class School:
    def __init__(self):
        pass

    def add_student(self, name, grade):
        pass

    def roster(self):
        pass

    def grade(self, grade_number):
        pass
